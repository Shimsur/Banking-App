﻿using System;
using BankingApp.Services;

using BankingApp.Models;

class Program
{
    static void Main()
    {
        BankService bankService = new();

        while (true)
        {
            Console.WriteLine("\nWelcome to AwesomeGIC Bank! What would you like to do?");
            Console.WriteLine("[T] Input transactions");
            Console.WriteLine("[I] Define interest rules");
            Console.WriteLine("[P] Print statement");
            Console.WriteLine("[Q] Quit");

            char choice = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (char.ToUpper(choice))
            {
                case 'T':
                    Console.Write("\nEnter transaction details (YYYYMMDD Account Type Amount): ");
                    string[] transactionInput = Console.ReadLine().Split();
                    if (transactionInput.Length == 4)
                    {
                        DateTime date = DateTime.ParseExact(transactionInput[0], "yyyyMMdd", null);
                        string account = transactionInput[1];
                        char type = char.ToUpper(transactionInput[2][0]);
                        decimal amount = decimal.Parse(transactionInput[3]);

                        try
                        {
                            bankService.AddTransaction(date, account, type, amount);
                            Console.WriteLine("Transaction added successfully.");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error: {ex.Message}");
                        }
                    }
                    break;

                case 'I':
                    // Handle Define Interest Rules
                    while (true)
                    {
                        Console.Write("\nEnter interest rule details (YYYYMMDD RuleId Rate): ");
                        string[] ruleInput = Console.ReadLine().Split();
                        if (ruleInput.Length == 3)
                        {
                            DateTime date = DateTime.ParseExact(ruleInput[0], "yyyyMMdd", null);
                            string ruleId = ruleInput[1];
                            decimal rate = decimal.Parse(ruleInput[2]);

                            // Validate rate
                            if (rate <= 0 || rate >= 100)
                            {
                                Console.WriteLine("❌ Invalid rate! Rate must be between 0 and 100.");
                                continue;
                            }

                            try
                            {
                                bankService.AddInterestRule(date, ruleId, rate);
                                Console.WriteLine("Interest rule added successfully.");

                                // Show all interest rules after adding new rule
                                DisplayInterestRules(bankService);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Error: {ex.Message}");
                            }
                        }
                        else if (ruleInput.Length == 0)
                        {
                            // If no input (empty), break the loop and return to main menu
                            break;
                        }
                        else
                        {
                            Console.WriteLine("❌ Invalid format! Use YYYYMMDD RuleId Rate.");
                        }
                    }
                    break;

                case 'P':
                    Console.Write("\nEnter account and month (Account YYYYMM): ");
                    string[] statementInput = Console.ReadLine().Split();
                    if (statementInput.Length == 2)
                    {
                        string account = statementInput[0];
                        int year = int.Parse(statementInput[1].Substring(0, 4));
                        int month = int.Parse(statementInput[1].Substring(4, 2));

                        var transactions = bankService.GetAccountStatement(account, year, month);
                        Console.WriteLine($"Account: {account}");
                        Console.WriteLine("| Date     | Txn Id      | Type | Amount | Balance |");
                        foreach (var txn in transactions)
                        {
                            // Calculate the balance at the time of the transaction
                            decimal balance = transactions.TakeWhile(t => t.Date <= txn.Date).Sum(t => t.Type == 'D' ? t.Amount : -t.Amount);
                            Console.WriteLine($"| {txn.Date:yyyyMMdd} | {txn.TransactionId} | {txn.Type} | {txn.Amount,7:F2} | {balance,8:F2} |");
                        }

                        // Calculate and display interest for the specified month
                        decimal interest = bankService.CalculateInterestForMonth(account, year, month);
                        Console.WriteLine($"Interest for the month: {interest:F2}");
                    }
                    break;

                case 'Q':
                    Console.WriteLine("Thank you for banking with AwesomeGIC Bank.\nHave a nice day!");
                    return;

                default:
                    Console.WriteLine("Invalid choice, please try again.");
                    break;
            }
        }
    }

    // Helper method to display all interest rules
    static void DisplayInterestRules(BankService bankService)
    {
        var rules = bankService.GetInterestRules();
        Console.WriteLine("\n📜 Interest Rules:");
        Console.WriteLine("| Date     | RuleId | Rate (%) |");
        foreach (var rule in rules)
        {
            Console.WriteLine($"| {rule.Date:yyyyMMdd} | {rule.RuleId} | {rule.Rate,8:F2} |");
        }
    }
}
