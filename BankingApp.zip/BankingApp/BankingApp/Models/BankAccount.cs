﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BankingApp.Models
{
    public class BankAccount
    {
        public string AccountNumber { get; private set; }
        public List<Transaction> Transactions { get; private set; }
        public decimal Balance { get; private set; }

        public BankAccount(string accountNumber)
        {
            AccountNumber = accountNumber;
            Transactions = new List<Transaction>();
            Balance = 0;
        }

        // Add a transaction to the account
        public void AddTransaction(Transaction transaction)
        {
            if (transaction.Type == 'W' && Balance < transaction.Amount)
            {
                throw new InvalidOperationException("Insufficient balance.");
            }

            Transactions.Add(transaction);
            Balance += transaction.Type == 'D' ? transaction.Amount : -transaction.Amount;
        }

        // Apply interest calculation based on the interest rules and the transactions
        public decimal ApplyInterest(List<InterestRule> interestRules, DateTime statementDate)
        {
            decimal totalInterest = 0;

            // Get the transactions for the month of the statement
            var relevantTransactions = Transactions
                .Where(t => t.Date.Month == statementDate.Month && t.Date.Year == statementDate.Year)
                .ToList();

            if (relevantTransactions.Count == 0)
            {
                return totalInterest; // No transactions to apply interest on
            }

            // Iterate through the days of the month to calculate interest based on the EOD balance
            for (int day = 1; day <= DateTime.DaysInMonth(statementDate.Year, statementDate.Month); day++)
            {
                var date = new DateTime(statementDate.Year, statementDate.Month, day);

                // Get the applicable interest rate based on the date
                var applicableRule = interestRules
                    .Where(rule => rule.Date <= date)
                    .OrderByDescending(rule => rule.Date)
                    .FirstOrDefault();

                if (applicableRule == null)
                    continue; // No applicable interest rule for this date

                // Calculate interest for this day based on the end-of-day balance
                decimal dailyRate = applicableRule.Rate / 100 / 365; // Annual rate divided by 365 for daily rate
                totalInterest += Balance * dailyRate;
            }

            // Round the calculated interest to two decimal places and return it
            return Math.Round(totalInterest, 2);
        }
    }
}

