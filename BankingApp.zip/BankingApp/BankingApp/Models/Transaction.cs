﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace BankingApp.Models
{
    public class Transaction
    {
        public DateTime Date { get; }
        public string TransactionId { get; }
        public string AccountNumber { get; }
        public char Type { get; }
        public decimal Amount { get; }

        public Transaction(DateTime date, string transactionId, string accountNumber, char type, decimal amount)
        {
            Date = date;
            TransactionId = transactionId;
            AccountNumber = accountNumber;
            Type = type;
            Amount = amount;
        }
    }
}

