﻿using System;
using System.Collections.Generic;
using System.Linq;
using BankingApp.Models;


namespace BankingApp.Services
{
    public class BankService
    {
        private Dictionary<string, BankAccount> _accounts = new();
        private List<InterestRule> _interestRules = new();

        // Add a transaction to the specified account
        public void AddTransaction(DateTime date, string accountNumber, char type, decimal amount)
        {
            if (!_accounts.ContainsKey(accountNumber))
            {
                _accounts[accountNumber] = new BankAccount(accountNumber);
            }

            string transactionId = $"{date:yyyyMMdd}-{_accounts[accountNumber].Transactions.Count + 1:D2}";
            var transaction = new Transaction(date, transactionId, accountNumber, type, amount);

            _accounts[accountNumber].AddTransaction(transaction);
        }

        // Add or update an interest rule
        public void AddInterestRule(DateTime date, string ruleId, decimal rate)
        {
            // Remove any existing rule on the same date and add the new one
            _interestRules.RemoveAll(r => r.Date == date);
            _interestRules.Add(new InterestRule(date, ruleId, rate));
        }

        // Get a list of interest rules sorted by date
        public List<InterestRule> GetInterestRules()
        {
            return _interestRules.OrderBy(rule => rule.Date).ToList();
        }

        // Get account statement for a specific account and month
        public List<Transaction> GetAccountStatement(string accountNumber, int year, int month)
        {
            if (!_accounts.ContainsKey(accountNumber))
            {
                return new List<Transaction>();
            }

            var account = _accounts[accountNumber];
            var transactions = account.Transactions.Where(t => t.Date.Year == year && t.Date.Month == month).ToList();

            // Calculate interest for the specified month and add it as a new transaction
            decimal totalInterest = CalculateInterestForMonth(accountNumber, year, month);
            if (totalInterest > 0)
            {
                var interestTransaction = new Transaction(
                    new DateTime(year, month, DateTime.DaysInMonth(year, month)),
                    $"{accountNumber}-I",
                    accountNumber,
                    'I',
                    totalInterest
                );
                transactions.Add(interestTransaction);
            }

            return transactions;
        }

        // Calculate interest for an account for a specific month
        public decimal CalculateInterestForMonth(string accountNumber, int year, int month)
        {
            if (!_accounts.ContainsKey(accountNumber))
            {
                throw new InvalidOperationException("Account not found.");
            }

            var account = _accounts[accountNumber];
            decimal interest = 0;

            // Get the transactions for the month
            var monthlyTransactions = account.Transactions.Where(t => t.Date.Year == year && t.Date.Month == month).ToList();

            // Get the interest rules applicable for this month
            var applicableRules = _interestRules.Where(rule =>
                rule.Date.Year <= year && rule.Date.Month <= month).OrderBy(rule => rule.Date).ToList();

            // Loop through the days in the month
            for (int day = 1; day <= DateTime.DaysInMonth(year, month); day++)
            {
                var currentDate = new DateTime(year, month, day);

                // Get the applicable interest rule for this date
                var rule = applicableRules.LastOrDefault(r => r.Date <= currentDate);
                if (rule != null)
                {
                    // Find the balance at the end of the day
                    decimal dailyBalance = monthlyTransactions.Where(t => t.Date <= currentDate)
                                                              .Sum(t => t.Type == 'D' ? t.Amount : -t.Amount);

                    // Calculate interest for this day
                    interest += (dailyBalance * rule.Rate / 100m) / 365m;
                }
            }

            return Math.Round(interest, 2); // Round the interest to two decimal places
        }
    }
}

