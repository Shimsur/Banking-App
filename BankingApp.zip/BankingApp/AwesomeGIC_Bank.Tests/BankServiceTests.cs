﻿

using System;
using Xunit;
using BankingApp.Services;
using BankingApp.Models;

namespace BankingApp.Tests
{
    public class BankServiceTests
    {
        private readonly BankService _bankService;

        public BankServiceTests()
        {
            _bankService = new BankService();
        }

        [Fact]
        public void AddTransaction_ShouldUpdateBalance_WhenTransactionIsDeposited()
        {
            var accountNumber = "123456";
            var depositAmount = 1000m;

            _bankService.AddTransaction(DateTime.Now, accountNumber, 'D', depositAmount);

            var account = _bankService.GetAccountStatement(accountNumber, DateTime.Now.Year, DateTime.Now.Month);
            Assert.Equal(depositAmount, account[0].Amount);
        }

        [Fact]
        public void AddTransaction_ShouldThrowException_WhenInsufficientBalanceForWithdrawal()
        {
            var accountNumber = "123456";
            var withdrawalAmount = 1000m;

            _bankService.AddTransaction(DateTime.Now, accountNumber, 'D', 500m);

            var exception = Assert.Throws<InvalidOperationException>(() =>
                _bankService.AddTransaction(DateTime.Now, accountNumber, 'W', withdrawalAmount));

            Assert.Equal("Insufficient balance.", exception.Message);
        }

        [Fact]
        public void CalculateInterest_ShouldReturnCorrectInterest_WhenInterestRuleIsApplied()
        {
            var accountNumber = "123456";
            var ruleDate = DateTime.Now.AddMonths(-1);
            var interestRate = 5m;

            // Adding interest rule
            _bankService.AddInterestRule(ruleDate, "Rule1", interestRate);

            // Add a deposit transaction to account
            _bankService.AddTransaction(DateTime.Now, accountNumber, 'D', 1000m);

            var transactions = _bankService.GetAccountStatement(accountNumber, DateTime.Now.Year, DateTime.Now.Month);
            var totalInterest = _bankService.CalculateInterestForMonth(accountNumber, DateTime.Now.Year, DateTime.Now.Month);

            Assert.True(totalInterest > 0);
        }
    }
}
