using System;
using Xunit;
using BankingApp.Models;  // Import your main project namespace

namespace AwesomeGIC_Bank.Models
{
    public class Transaction
    {
        // Properties for Transaction class
        public DateTime Date { get; set; }
        public string AccountId { get; set; }
        public char Type { get; set; }  // 'D' for Deposit, 'W' for Withdrawal
        public decimal Amount { get; set; }
        public string TransactionId { get; set; }

        // Constructor to initialize the Transaction object
        public Transaction(DateTime date, string accountId, char type, decimal amount)
        {
            Date = date;
            AccountId = accountId;
            Type = type;
            Amount = amount;

            // Generate a unique transaction ID in the format YYYYMMDD-xx
            string datePart = date.ToString("yyyyMMdd");
            string transactionCount = "01"; // This can be dynamic if you want to track transaction numbers
            TransactionId = $"{datePart}-{transactionCount}";
        }
    }
}
