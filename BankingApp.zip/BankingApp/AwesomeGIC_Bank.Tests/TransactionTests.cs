﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;
using BankingApp.Models;

namespace BankingApp.Tests
{
    public class TransactionTests
    {
        [Fact]
        public void Transaction_ShouldCreateCorrectTransactionWithDeposit()
        {
            var transaction = new Transaction(DateTime.Now, "Txn1", "123456", 'D', 500m);

            Assert.Equal('D', transaction.Type);
            Assert.Equal(500m, transaction.Amount);
        }

        [Fact]
        public void Transaction_ShouldCreateCorrectTransactionWithWithdrawal()
        {
            var transaction = new Transaction(DateTime.Now, "Txn2", "123456", 'W', 300m);

            Assert.Equal('W', transaction.Type);
            Assert.Equal(300m, transaction.Amount);
        }
    }
}
