﻿using System;
using BankingApp.Models;

namespace BankingApp.Tests.TestHelpers
{
    public static class TestDataHelper
    {
        public static BankAccount CreateTestAccount(string accountNumber, decimal initialDeposit = 0m)
        {
            var account = new BankAccount(accountNumber);
            if (initialDeposit > 0)
            {
                account.AddTransaction(new Transaction(DateTime.Now, "Txn1", accountNumber, 'D', initialDeposit));
            }
            return account;
        }

        public static InterestRule CreateTestInterestRule(DateTime date, string ruleId, decimal rate)
        {
            return new InterestRule(date, ruleId, rate);
        }

        public static Transaction CreateTestTransaction(string accountNumber, char type, decimal amount)
        {
            return new Transaction(DateTime.Now, $"Txn{new Random().Next()}", accountNumber, type, amount);
        }
    }
}
