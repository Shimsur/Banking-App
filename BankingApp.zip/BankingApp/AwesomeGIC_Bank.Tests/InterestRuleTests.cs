﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;
using BankingApp.Models;

namespace BankingApp.Tests
{
    public class InterestRuleTests
    {
        [Fact]
        public void AddInterestRule_ShouldAddRuleWithValidRate()
        {
            var rule = new InterestRule(DateTime.Now, "Rule1", 5m);

            Assert.Equal(5m, rule.Rate);
        }

        [Fact]
        public void AddInterestRule_ShouldThrowException_WhenRateIsInvalid()
        {
            var exception = Assert.Throws<ArgumentOutOfRangeException>(() =>
                new InterestRule(DateTime.Now, "Rule1", -1m));

            Assert.Equal("Rate must be between 0 and 100", exception.Message);
        }
    }
}
