﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xunit;
using BankingApp.Models;

namespace BankingApp.Tests
{
    public class BankAccountTests
    {
        [Fact]
        public void AddTransaction_ShouldUpdateBalance_WhenDepositIsMade()
        {
            var account = new BankAccount("123456");
            account.AddTransaction(new Transaction(DateTime.Now, "Txn1", "123456", 'D', 1000m));

            Assert.Equal(1000m, account.Balance);
        }

        [Fact]
        public void AddTransaction_ShouldThrowException_WhenWithdrawalExceedsBalance()
        {
            var account = new BankAccount("123456");
            account.AddTransaction(new Transaction(DateTime.Now, "Txn1", "123456", 'D', 500m));

            var exception = Assert.Throws<InvalidOperationException>(() =>
                account.AddTransaction(new Transaction(DateTime.Now, "Txn2", "123456", 'W', 1000m)));

            Assert.Equal("Insufficient balance.", exception.Message);
        }
    }
}
